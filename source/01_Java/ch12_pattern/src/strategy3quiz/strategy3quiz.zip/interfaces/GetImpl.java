package strategy3quiz.interfaces;

public interface GetImpl {

	public void get();
	
}
