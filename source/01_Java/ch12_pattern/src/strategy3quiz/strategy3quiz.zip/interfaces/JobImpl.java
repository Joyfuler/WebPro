package strategy3quiz.interfaces;

public interface JobImpl {

	public void job();
	
}
